userPrompt = "Enter the Book Title:"

length = len(input(userPrompt))

print("The length of the title is:", length, "characters long")