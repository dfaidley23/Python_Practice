# while True:
#     print("HI")

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# password = input("Please Enter A Password: ")

# while password != "password":
#     password = input("Please Enter A Password: ")

# print("Please Try Again.")

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# x = 1

# while x <= 10:
#     print(x)
#     x = x + 1